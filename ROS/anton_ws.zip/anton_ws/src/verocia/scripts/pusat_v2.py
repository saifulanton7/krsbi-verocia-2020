#!/usr/bin/env python
import rospy
import json
from std_msgs.msg import String
from std_msgs.msg import UInt16

class PubSub(object):
    def __init__(self):
        rospy.init_node('pubsub')
	self.manuver = 0
        self.camera_sub = rospy.Subscriber('camera',String,self.callback)
        self.motor_pub = rospy.Publisher('motor', UInt16,queue_size=1)


    def callback(self,data):
    	variabel = data.data
    	variabel_dict = json.loads(variabel)
    	x = variabel_dict['x']
    	y = variabel_dict['y']

    	print("X = "+ str(x) + ", Y = " + str(y))    
    	if(x>0 and x<=200):
		print("ROBOT BELOK KIRI")
		manuver = 6
    	elif(x>430):
		print("ROBOT BELOK KANAN")
		manuver = 5
 	elif(x==0):
		print("ROBOT MENCARI BOLA")
		manuver = 8
    	elif(x>200 and x<430):
		if(y<=420): 
			manuver = 1
			print("ROBOT MAJU")
		else: 
			manuver = 0
			print("ROBOT BERHENTI")
	newMsg = manuver
	self.motor_pub.publish(newMsg);
	rospy.loginfo(newMsg)


if __name__ == '__main__':
    try:
        a = PubSub()
        rospy.spin()
    except rospy.ROSInterruptException: pass
