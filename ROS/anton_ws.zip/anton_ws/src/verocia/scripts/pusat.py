#!/usr/bin/env python
import rospy
import json
from std_msgs.msg import String

manuver = 0



def callback(data):
    variabel = data.data
    variabel_dict = json.loads(variabel)
    x = variabel_dict['x']
    y = variabel_dict['y']

    print("X = "+ str(x) + ", Y = " + str(y))    
    if(x>0 and x<=200):
	print("ROBOT BELOK KIRI")
	manuver = 3
    elif(x>430):
	print("ROBOT BELOK KANAN")
	manuver = 2

    elif(x==0):
	print("ROBOT MENCARI BOLA")
	manuver = 8
    elif(x>200 and x<430):
	if(y<=350): 
		manuver = 1
		print("ROBOT MAJU")
	else: 
		manuver = 0
		print("ROBOT BERHENTI")
    print(manuver)
    rospy.init_node('talker', anonymous=True)
    pub = rospy.Publisher('motor', String, queue_size=10)
    hello_str = str(manuver)
    pub.publish(hello_str)
    print("OK")


def listener():
    rospy.init_node('camera', anonymous=True)
    rospy.Subscriber("camera", String, callback)
    rospy.spin()

if __name__ == '__main__':
    listener()
